from django.apps import AppConfig

class WooMysqlTuneupConfig(AppConfig):
    name = 'woo_mysql_tuneup'
