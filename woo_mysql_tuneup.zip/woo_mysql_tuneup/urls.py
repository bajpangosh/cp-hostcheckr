from django.conf.urls import url
from woo_mysql_tuneup import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^save_config$', views.save_config, name='save_config'),
]
