# WooCommerce MySQL Tuneup Plugin

This plugin allows you to tune MySQL settings for WooCommerce performance directly from CyberPanel.

## Installation

1. Upload the `woo_mysql_tuneup` folder to `/usr/local/CyberCP/public/` on your server.
2. Go to CyberPanel > Plugins > Plugin Installer.
3. Install the plugin.

## Debugging

To enable debugging for this plugin (and CyberPanel in general), follow these steps:

### automatic Method (Recommended for Devs)

We have included scripts to easily enable/disable debug mode.

1. SSH into your server.
2. Navigate to the plugin directory: `cd /usr/local/CyberCP/public/woo_mysql_tuneup`
3. Run the enable script:
   ```bash
   chmod +x enable_debug.sh
   ./enable_debug.sh
   ```
4. To disable:
   ```bash
   chmod +x disable_debug.sh
   ./disable_debug.sh
   ```

### Manual Method

1. Create the debug flag file:
   ```bash
   touch /usr/local/CyberCP/debug
   ```
2. Restart CyberPanel:
   ```bash
   systemctl restart lscpd
   ```
3. Monitor logs:
   ```bash
   tail -f /home/cyberpanel/error-logs.txt
   ```

### Checking Plugin Logs

This plugin uses `CyberCPLogFileWriter` to write to the main CyberPanel log.
Look for entries starting with `WooMysqlTuneup:` in `/home/cyberpanel/error-logs.txt` or `/base/pyLog`.
