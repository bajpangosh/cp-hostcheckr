from django.shortcuts import render, HttpResponse
import os
import subprocess
import traceback
from plogical.CyberCPLogFileWriter import CyberCPLogFileWriter as logging
from plogical.processUtilities import ProcessUtilities

def get_mysql_config():
    config_path = '/etc/my.cnf'
    config = {}
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            for line in f:
                if '=' in line and not line.strip().startswith('#'):
                    key, value = line.strip().split('=', 1)
                    config[key.strip()] = value.strip()
    return config

def index(request):
    try:
        if os.path.exists(ProcessUtilities.debugPath):
            logging.writeToFile("=== WooMysqlTuneup DEBUG MODE ACTIVE ===")
            logging.writeToFile(f"Request method: {request.method}")
            logging.writeToFile(f"Request path: {request.path}")

        current_config = get_mysql_config()
        context = {
            'innodb_buffer_pool_size': current_config.get('innodb_buffer_pool_size', '1G'),
            'max_connections': current_config.get('max_connections', '150'),
            'innodb_log_file_size': current_config.get('innodb_log_file_size', '256M'),
            'innodb_flush_log_at_trx_commit': current_config.get('innodb_flush_log_at_trx_commit', '1'),
        }
        return render(request, 'woo_mysql_tuneup/index.html', context)
    except Exception as e:
        error_msg = str(traceback.format_exc())
        logging.writeToFile(f"WooMysqlTuneup Plugin Error: {error_msg}")
        return HttpResponse(f"Plugin Error: {str(e)}")

def save_config(request):
    try:
        if request.method == 'POST':
        logging.writeToFile('WooMysqlTuneup: Starting save_config')
        innodb_buffer_pool_size = request.POST.get('innodb_buffer_pool_size')
        max_connections = request.POST.get('max_connections')
        innodb_log_file_size = request.POST.get('innodb_log_file_size')
        innodb_flush_log_at_trx_commit = request.POST.get('innodb_flush_log_at_trx_commit')

        # Basic validation could go here

        lines = []
        config_path = '/etc/my.cnf'
        
        # Read existing file to preserve other settings
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                lines = f.readlines()
        
        # Update or append new values
        new_settings = {
            'innodb_buffer_pool_size': innodb_buffer_pool_size,
            'max_connections': max_connections,
            'innodb_log_file_size': innodb_log_file_size,
            'innodb_flush_log_at_trx_commit': innodb_flush_log_at_trx_commit,
        }
        
        updated_lines = []
        keys_updated = set()
        
        for line in lines:
            stripped = line.strip()
            if '=' in stripped and not stripped.startswith('#'):
                key = stripped.split('=')[0].strip()
                if key in new_settings:
                    updated_lines.append(f"{key} = {new_settings[key]}\n")
                    keys_updated.add(key)
                else:
                    updated_lines.append(line)
            else:
                updated_lines.append(line)
        
        # Append missing keys under [mysqld] section if possible, otherwise at end (risky but simple for now)
        # Ideally we find [mysqld] and append there.
        
        for key, value in new_settings.items():
            if key not in keys_updated:
                updated_lines.append(f"{key} = {value}\n")

        try:
            with open(config_path, 'w') as f:
                f.writelines(updated_lines)
            
            # Restart MySQL
            logging.writeToFile('WooMysqlTuneup: Configuration saved. Restarting MySQL service...')
            subprocess.Popen(['service', 'mysqld', 'restart']) # Non-blocking might be better to avoid timeout
            
            return HttpResponse('Settings saved and MySQL restarting...')
        
        return HttpResponse('Invalid request method')
        
    except Exception as e:
        error_msg = str(traceback.format_exc())
        logging.writeToFile(f'WooMysqlTuneup Plugin Error: {error_msg}')
        return HttpResponse(f'Error saving settings: {str(e)}')
