#!/bin/bash

echo "--- Enabling CyberPanel Debug Mode ---"

# 1. Create debug flag
if [ ! -f /usr/local/CyberCP/debug ]; then
    touch /usr/local/CyberCP/debug
    echo "[OK] Debug flag created at /usr/local/CyberCP/debug"
else
    echo "[INFO] Debug flag already exists."
fi

# 2. Reminder for settings.py
echo ""
echo "[IMPORTANT] For full Django debugging (tracebacks in browser):"
echo "You must manually edit /usr/local/CyberCP/CyberCP/settings.py"
echo "and set 'DEBUG = True'. Also add your domain to 'ALLOWED_HOSTS'."
echo ""

# 3. Restart LSCPD
echo "Restarting LSCPD to apply changes..."
systemctl restart lscpd

echo "--- Debug Mode Enabled ---"
echo "Monitor logs with: tail -f /home/cyberpanel/error-logs.txt"
