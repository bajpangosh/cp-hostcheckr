#!/bin/bash

echo "--- Disabling CyberPanel Debug Mode ---"

# 1. Remove debug flag
if [ -f /usr/local/CyberCP/debug ]; then
    rm /usr/local/CyberCP/debug
    echo "[OK] Debug flag removed."
else
    echo "[INFO] Debug flag was not present."
fi

# 2. Reminder for settings.py
echo ""
echo "[IMPORTANT] If you changed 'DEBUG = True' in settings.py,"
echo "remember to set it back to 'DEBUG = False' for security!"
echo ""

# 3. Restart LSCPD
echo "Restarting LSCPD to apply changes..."
systemctl restart lscpd

echo "--- Debug Mode Disabled ---"
